# Guia de Migração: Do ROADMAP.md Gigante para Estrutura Organizada

## Resumo da Migração

```
ANTES (339KB em um arquivo)          DEPOIS (Estrutura organizada)
─────────────────────────────────    ─────────────────────────────────
ROADMAP.md (10.422 linhas)           docs/
├── Visão estratégica                ├── VISION.md (~100 linhas)
├── Fases e dependências             ├── MASTER-PLAN.md (~200 linhas)
├── Prompts de implementação    →    openspec/specs/*/spec.md (já existe!)
├── Código de exemplo                openspec/changes/*/tasks.md
├── Status de implementação          openspec/archive/ (já existe!)
└── Referência WLanguage             docs/wlanguage/ (já existe!)
                                     
                                     ROADMAP-LEGACY.md (arquivo de referência)
```

## Passos de Migração

### Passo 1: Criar novos arquivos (5 min)
```bash
cd /path/to/wx-killer

# Copiar arquivos propostos
cp VISION.md docs/VISION.md
cp MASTER-PLAN.md docs/MASTER-PLAN.md
```

### Passo 2: Arquivar ROADMAP antigo (1 min)
```bash
# Renomear para referência
mv docs/ROADMAP.md docs/ROADMAP-LEGACY.md
```

### Passo 3: Atualizar CLAUDE.md (10 min)
Simplificar o CLAUDE.md para apontar para a nova estrutura:

```markdown
# WX-KILLER

## Documentação
- [VISION.md](docs/VISION.md) - Visão estratégica e produtos
- [MASTER-PLAN.md](docs/MASTER-PLAN.md) - Fases e dependências
- [openspec/project.md](openspec/project.md) - Contexto técnico

## Workflow
Use OpenSpec para todas as mudanças:
- `/openspec:proposal` - Criar nova proposta
- `/openspec:apply` - Implementar
- `/openspec:archive` - Arquivar quando completo

## Estado Atual
Ver `docs/MASTER-PLAN.md` para fases e `openspec list` para changes ativos.
```

### Passo 4: Validar OpenSpec (2 min)
```bash
# Verificar que OpenSpec está íntegro
openspec list
openspec validate
```

### Passo 5: Testar o novo workflow (5 min)
```bash
# Criar um change de teste
/openspec:proposal Adicionar validação de sintaxe no código gerado

# Verificar que funciona normalmente
openspec show add-syntax-validator
```

## O que NÃO fazer

❌ **NÃO deletar** o ROADMAP-LEGACY.md
   - Pode ter informações úteis para consulta
   - Mantém histórico de decisões

❌ **NÃO migrar para Spec Kit**
   - OpenSpec já está funcionando bem
   - Histórico seria perdido ou complicado de migrar
   - Retrabalho desnecessário

❌ **NÃO colocar prompts detalhados** no MASTER-PLAN.md
   - Prompts vão para `tasks.md` dentro de cada change
   - MASTER-PLAN é só visão de alto nível

## Checklist de Migração

- [ ] Criar `docs/VISION.md`
- [ ] Criar `docs/MASTER-PLAN.md`
- [ ] Renomear `docs/ROADMAP.md` → `docs/ROADMAP-LEGACY.md`
- [ ] Atualizar `CLAUDE.md` com links para novos arquivos
- [ ] Verificar OpenSpec com `openspec list`
- [ ] Commitar mudanças: "docs: reestruturar documentação em VISION + MASTER-PLAN"

## Manutenção Futura

### Quando atualizar VISION.md
- Mudanças na visão estratégica do produto
- Novos produtos derivados
- Mudanças nos princípios arquiteturais

### Quando atualizar MASTER-PLAN.md
- Nova fase adicionada
- Fase concluída (marcar ✅)
- Mudança nas dependências entre fases
- Novos changes planejados

### Quando usar OpenSpec
- **Sempre** que for implementar algo
- Para documentar requirements detalhados
- Para tracking de progresso de implementação

## Benefícios Esperados

| Métrica | Antes | Depois |
|---------|-------|--------|
| Tamanho do "roadmap" | 339KB | ~15KB total |
| Tempo para entender estado atual | Ler 10k linhas | `openspec list` |
| Onde adicionar nova fase | "Em algum lugar do ROADMAP" | MASTER-PLAN.md |
| Onde adicionar requirements | "No prompt da fase X" | OpenSpec spec |
| Onde está o histórico | Perdido no ROADMAP | openspec/archive/ |
